# Star Wars 05

## File

* `server5.js`

## Instructions

* Spend a few moments researching what `express.json` is for and what `req.body` means in the context of Express.

  * Then research how you can POST data to the Express server.

### Bonus

* Use Postman to send a POST request to the server you've been provided. Confirm that your character has been added to the database correctly.
