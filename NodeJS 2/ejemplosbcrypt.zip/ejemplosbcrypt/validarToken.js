let jsonwebtoken = require("jsonwebtoken")
let SECRET = process.env.SECRET || "secret1234"


let token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJFc0FkbWluIjp0cnVlLCJ1c2VyaWQiOjEsImlhdCI6MTY0Mzc1OTcwNSwiZXhwIjoxNjQzNzU5NzA1fQ.yJEuGyRsiLL3UoV4GBMXhS7oXXdZ1Kg4zbC21gmTGGk'

jsonwebtoken.verify(token,SECRET,(err,data) => {

 if (err) {
    console.log(err)
 }
 else {
console.log('Token valido')

console.log(data.EsAdmin)
console.log(data.userid)

 }

})