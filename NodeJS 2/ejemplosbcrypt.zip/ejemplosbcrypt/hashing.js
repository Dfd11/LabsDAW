let bcrypt = require("bcrypt")


// (1) Generar la sal
let salt =  bcrypt.genSaltSync()
console.log(`Salt: ${salt}`)

// (2) Password original 

let password_original = "1234"

// (3) le aplicamos un hash

console.time('hashtime')
let password_hash = bcrypt.hashSync(password_original,salt)
console.log(`Password hash: ${password_hash}`)
console.timeEnd('hashtime')

// (4)
let valido = bcrypt.compareSync("1234",password_hash)
console.log(valido)

