let jsonwebtoken = require("jsonwebtoken")

let SECRET = process.env.SECRET || "secret1234"

jsonwebtoken.sign({EsAdmin: true, userid:1},SECRET,{expiresIn: '120'}, (err, token) => {

if (err) {
    console.log(err)
}
else {
    console.log(token)
}

})



//eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJFc0FkbWluIjp0cnVlLCJ1c2VyaWQiOjEsImlhdCI6MTY0Mzc1OTMxNCwiZXhwIjoxNjQzNzYyOTE0fQ.bV7Ma9d3S-PUAt0vLFRDhRLD7n-36A8wUVDuTYd8g10